// server2.js
import express from 'express';
import http from 'http';
import { Server } from 'socket.io';
import mysql from 'mysql2/promise';
import dotenv from 'dotenv';

dotenv.config();

// การตั้งค่าการเชื่อมต่อ MySQL
const dbConfig = {
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT
};

// สร้าง connection pool
const pool = mysql.createPool(dbConfig);

const app = express();
const server = http.createServer(app);
const io = new Server(server);


// เก็บ client ID และ socket ที่เชื่อมต่อ
let clients = {};

///////// Socket.IO //////////

// เมื่อ client เชื่อมต่อ
io.on('connection', (socket) => {

    // ให้ client ส่งข้อมูล hosCode และ hosName เมื่อเชื่อมต่อ
    socket.on('register', (clientInfo) => {
        const { hosCode, hosName } = clientInfo;
        clients[hosCode] = socket;  // เก็บ client ID (hosCode) กับ socket
        console.log(`Client ${hosCode} (${hosName}) connected`);

        // ส่งข้อความทักทายไปยัง client เมื่อเชื่อมต่อสำเร็จ
        socket.emit('greeting', `<-- Server: สวัสดีครับ! ยินดีต้อนรับ [${hosCode}] (${socket.id})`);
    });

    // รับข้อมูลจาก client
    socket.on('clientData', async (data) => {
        const { hosCode, queryName, data: json_data } = data;
        console.log('Received json_data: ', json_data);
    
        // ตรวจสอบว่า json_data เป็น array หรือไม่
        // console.log('Checking json_data format...');
        // console.log('Is json_data an array? ', Array.isArray(json_data));
        // console.log('json_data length: ', json_data.length);

        // console.log('json_data type: ', typeof json_data);  // ตรวจสอบว่า json_data เป็น string หรือ object
    
        let newJsonData;
    
        // หาก json_data เป็น string, ให้พยายามแปลงเป็น JSON
        if (typeof json_data === 'string') {
            try {
                newJsonData = JSON.parse(json_data);  // แปลง JSON string เป็น object
                console.log('json_data after parsing: ', newJsonData);
            } catch (error) {
                console.error('Error parsing json_data: ', error);
                socket.emit('error', 'Invalid JSON format');
                return;
            }
        } else {
            newJsonData = json_data; // หากไม่เป็น string ให้ใช้ json_data ตรง ๆ
        }
    
        // ตรวจสอบว่า newJsonData เป็น array หรือไม่
        if (Array.isArray(newJsonData) && newJsonData.length > 0) {
            console.log('newJsonData is valid array');
    
            // สร้างคอลัมน์จาก key ของข้อมูลใน newJsonData ตัวแรก
            const columns = Object.keys(newJsonData[0]).join(', ');
            console.log('Columns: ', columns);
    
            // สร้างค่า values ที่จะนำไปใช้ใน REPLACE INTO
            const values = newJsonData.map(item => {
                return `(${Object.values(item).map(value => {
                    // ตรวจสอบและจัดการค่าที่เป็น null หรือ undefined ก่อน
                    if (value === null || value === undefined) {
                        return 'NULL'; // ให้ค่า NULL สำหรับ null หรือ undefined
                    }
                    return pool.escape(value);  // ใช้ pool.escape กับค่าที่ไม่เป็น null หรือ undefined
                }).join(', ')})`;
            }).join(', ');
            console.log('Values: ', values);
    
            // สร้างคำสั่ง REPLACE INTO
            const sql = `REPLACE INTO ${queryName} (${columns}) VALUES ${values}`;
            console.log('Generated SQL: ', sql);
    
            try {
                // ใช้ connection pool ในการ query
                const [results] = await pool.execute(sql);
                console.log('Data successfully inserted:', results);
                socket.emit('dataResponse', {'message: ': 'Data inserted successfully', 'results: ': results});
            } catch (err) {
                console.error('Error executing query: ', err);
                socket.emit('dataResponse', {'message: ': 'Error, not insert', 'results: ': err});
            }
        } else {
            console.log('Invalid data format');
            socket.emit('error', 'Invalid data format');
        }
    });

    
    
    
    
    
    
    
    
    
    


    // เมื่อ client disconnect
    socket.on('disconnect', () => {
        // ลบ client ที่ disconnect ออกจาก object
        for (let hosCode in clients) {
            if (clients[hosCode] === socket) {
                delete clients[hosCode];
                console.log(`Client ${hosCode} disconnected`);
                break;
            }
        }
    });
});

// เริ่มต้นเซิร์ฟเวอร์ที่ port 3000
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});


////////// ExpressJS //////////

// กำหนด route สำหรับการส่งคำสั่งแบบ dynamic
app.post('/query/:queryName/:hosCode', (req, res) => {
    const { queryName, hosCode } = req.params;

    // ดึงค่าทั้งหมดจาก query parameters
    const queryParams = req.query;  // จะได้เป็น object ที่มีพารามิเตอร์ต่างๆ

    // สร้าง array เก็บค่าพารามิเตอร์ทั้งหมด (name, value)
    const paramsArray = [];
    for (let [key, value] of Object.entries(queryParams)) {
        paramsArray.push({ key, value }); // เก็บ key-value pair ลงใน array
    }

    // ตรวจสอบว่ามี client ที่มี hosCode ตรงกับที่ได้รับหรือไม่
    if (clients[hosCode]) {
        // ส่งคำสั่งไปยัง client แบบระบุ hosCode พร้อมส่ง paramsArray
        clients[hosCode].emit('serverCommand', { queryName, hosCode, params: paramsArray });
        console.log(`Server ส่งคำสั่ง ${queryName} ไปยัง ${hosCode} (${clients[hosCode] ? 'OK' : 'Not found'})`);
        res.status(200).send(`Server ส่งคำสั่ง ${queryName} ไปยัง ${hosCode} (${clients[hosCode] ? 'OK' : 'Not found'})`);
    } else {
        res.status(404).send(`Client ${hosCode} not found`);
    }
});